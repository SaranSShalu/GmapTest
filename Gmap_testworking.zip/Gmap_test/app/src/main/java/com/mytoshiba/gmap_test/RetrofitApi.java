package com.mytoshiba.gmap_test;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface RetrofitApi {

    String URL_BASE = "https://dev.d-inventions.com/";

    @POST("api.php")
    Call<LocationResponse> createPost(@Body Data data);

}
